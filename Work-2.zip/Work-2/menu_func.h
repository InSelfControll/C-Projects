#ifndef MENU_FUNC_DOT_H
#define MENU_FUNC_DOT_H
int print_triangle();
int print_numbers(long int num) ;
int print_pascal_triangle();
int print_ascii();
#endif /* MENU_FUNC_DOT_H */
